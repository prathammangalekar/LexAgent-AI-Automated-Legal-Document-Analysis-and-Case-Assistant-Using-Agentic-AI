"""
Lab 14: Capstone Project Studio -- Integrated Mini System

A compact worklet ("Campus Help-Desk Agent") combining every element
the capstone rubric requires: node graph, 3+ tools, 1+ reusable skill,
memory/context design, prompt log, execution trace, evaluation,
a safety control, and a stated limitation/roadmap.
"""

from datetime import datetime

# ---- Tools (3+) -----------------------------------------------

FAQ_DB = {
    "wifi": "Connect to 'Campus-Secure' and log in with your student ID."
}

TICKET_DB = []


def tool_search_faq(query):
    for k, v in FAQ_DB.items():
        if k in query.lower():
            return {"found": True, "answer": v}

    return {"found": False}


def tool_create_ticket(issue):
    ticket_id = f"T-{len(TICKET_DB) + 1:03d}"

    TICKET_DB.append({
        "id": ticket_id,
        "issue": issue,
        "status": "open"
    })

    return {"ticket_id": ticket_id}


def tool_check_ticket_status(ticket_id):
    for t in TICKET_DB:
        if t["id"] == ticket_id:
            return t

    return {"error": "not found"}


# ---- Skill: triage-and-respond (reusable across many issue types) ----

def triage_skill(issue_text):
    """
    Instructions: search FAQ first; only escalate to a ticket
    if no FAQ match exists. Never fabricate an FAQ answer.
    """

    faq_result = tool_search_faq(issue_text)

    if faq_result["found"]:
        return {
            "resolution": "faq",
            "answer": faq_result["answer"]
        }

    ticket = tool_create_ticket(issue_text)

    return {
        "resolution": "escalated",
        "ticket_id": ticket["ticket_id"]
    }


# ---- Memory (short-term session + long-term ticket history) ----

class CapstoneMemory:

    def __init__(self):
        self.session = {}
        self.history = []

    def record(self, user, issue, outcome):
        entry = {
            "user": user,
            "issue": issue,
            "outcome": outcome,
            "date": datetime.now().isoformat(timespec="seconds")
        }

        self.history.append(entry)
        self.session["last_issue"] = issue


# ---- Node graph (simplified: intake -> triage -> respond -> log) ----

def node_graph_run(user, issue, memory, audit_log, prompt_log):

    prompt_log.append({
        "stage": "intake",
        "input": issue
    })

    # Safety control: reject empty/malicious-looking input before triage.
    if not issue.strip():
        audit_log.append({
            "stage": "intake",
            "result": "rejected",
            "reason": "empty issue text"
        })

        return {
            "rejected": True,
            "reason": "empty issue text"
        }

    outcome = triage_skill(issue)

    prompt_log.append({
        "stage": "triage",
        "output": outcome
    })

    # Respond node
    if outcome["resolution"] == "faq":
        response = outcome["answer"]

    else:
        response = (
            f"Ticket {outcome['ticket_id']} created; "
            "support will follow up."
        )

    memory.record(user, issue, outcome)

    audit_log.append({
        "stage": "complete",
        "user": user,
        "issue": issue,
        "outcome": outcome
    })

    return {
        "rejected": False,
        "response": response,
        "outcome": outcome
    }


# ---- Evaluation: a tiny regression suite over known issue types ----

def run_evaluation():

    cases = [
        ("How do I connect to wifi?", "faq"),
        ("My laptop charger is broken", "escalated")
    ]

    memory = CapstoneMemory()
    audit_log = []
    prompt_log = []

    results = []

    for issue, expected in cases:

        result = node_graph_run(
            "eval_user",
            issue,
            memory,
            audit_log,
            prompt_log
        )

        actual = result["outcome"]["resolution"]

        results.append({
            "issue": issue,
            "expected": expected,
            "actual": actual,
            "passed": actual == expected
        })

    return results


if __name__ == "__main__":

    memory = CapstoneMemory()
    audit_log = []
    prompt_log = []

    print("=== Run 1: FAQ match ===")

    r1 = node_graph_run(
        "alice",
        "How do I connect to wifi on campus?",
        memory,
        audit_log,
        prompt_log
    )

    print(r1)

    print("\n=== Run 2: Escalation (no FAQ match) ===")

    r2 = node_graph_run(
        "bob",
        "My laptop charger is broken",
        memory,
        audit_log,
        prompt_log
    )

    print(r2)

    print("\n=== Run 3: Safety control rejects empty input ===")

    r3 = node_graph_run(
        "carol",
        "   ",
        memory,
        audit_log,
        prompt_log
    )

    print(r3)

    print("\n=== Evaluation (tiny regression suite) ===")

    eval_results = run_evaluation()

    for r in eval_results:
        print(
            f"[{'PASS' if r['passed'] else 'FAIL'}] "
            f"{r['issue']} -> {r['actual']} "
            f"(expected {r['expected']})"
        )

    print("\n=== Prompt log ===")

    for p in prompt_log:
        print(p)

    print("\n=== Audit log ===")

    for a in audit_log:
        print(a)

    print("\n=== Long-term memory / history ===")

    for h in memory.history:
        print(h)

    print("\n=== Limitations & next-step roadmap ===")

    print("- FAQ matching is keyword-based, not semantic.")
    print("- No human-approval gate yet for ticket priority escalation.")
    print(
        "- Next step: add a retrieval-based FAQ match "
        "and a priority-classification skill."
    )